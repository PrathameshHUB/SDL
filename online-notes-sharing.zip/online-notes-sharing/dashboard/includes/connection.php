<?php
$conn = new mysqli('localhost', 'root', '', 'online_notes'); // ✅ Use the correct database name

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
