<style>
/* Navbar Styles */
:root {
    --navbar-bg: #1e293b;
    --navbar-text: #f8fafc;
    --navbar-hover: #334155;
    --navbar-active: #6366f1;
    --navbar-dropdown-bg: #334155;
    --navbar-accent: #8b5cf6;
    --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

.navbar {
    border: none;
    border-radius: 0;
    margin-bottom: 0;
    background-color: var(--navbar-bg);
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
    min-height: 70px;
    transition: var(--transition);
    z-index: 1000;
}

.navbar-brand {
    font-weight: 700;
    font-size: 1.5rem;
    color: var(--navbar-text);
    display: flex;
    align-items: center;
    padding: 22px 15px;
    height: 70px;
}

.navbar-brand:hover {
    color: white;
}

.navbar-toggle {
    margin-top: 17px;
    border: none;
}

.navbar-toggle .icon-bar {
    background-color: var(--navbar-text);
    width: 22px;
    transition: var(--transition);
}

.navbar-toggle:hover .icon-bar {
    background-color: var(--navbar-accent);
}

.top-nav {
    margin-right: 15px;
}

.top-nav > li > a {
    color: var(--navbar-text);
    padding: 25px 15px;
    height: 70px;
    display: flex;
    align-items: center;
    font-weight: 500;
    transition: var(--transition);
}

.top-nav > li > a:hover,
.top-nav > li > a:focus {
    background-color: var(--navbar-hover);
    color: white;
}

.top-nav > li > a.upload-btn {
    background-color: var(--navbar-accent);
    margin-left: 10px;
    border-radius: 6px;
    padding: 8px 15px;
    height: auto;
    margin-top: 17px;
}

.top-nav > li > a.upload-btn:hover {
    background-color: #7c3aed;
    transform: translateY(-2px);
}

.dropdown-menu {
    background-color: var(--navbar-dropdown-bg);
    border: none;
    border-radius: 8px;
    box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
    padding: 0;
    margin-top: 0;
}

.dropdown-menu > li > a {
    color:  #1e293b;
    padding: 10px 20px;
    transition: var(--transition);
}

.dropdown-menu > li > a:hover {
    background-color: var(--navbar-hover);
    color: white;
}

.dropdown-menu .divider {
    background-color: #475569;
    margin: 0;
}

.side-nav {
    background-color: var(--navbar-bg);
    width: 229px;
    padding: 0;
    margin: 0;
    margin-top:19px;
    margin-left: -229px; /* Moves it 10px to the left */
}


.side-nav > li {
    border-bottom: 1px solid #334155;
}

.side-nav > li:first-child {
    border-top: 1px solid #334155;
}

.side-nav > li > a {
    color: var(--navbar-text);
    padding: 15px 20px;
    display: flex;
    align-items: center;
    transition: var(--transition);
}

.side-nav > li > a:hover {
    background-color: var(--navbar-hover);
    color: white;
    padding-left: 25px;
}

.side-nav > li > a.active {
    background-color: var(--navbar-active);
    color: white;
}

.side-nav > li > a > i {
    margin-right: 10px;
    width: 20px;
    text-align: center;
}

.side-nav .collapse {
    background-color: #1a2233;
    padding: 0;
}

.side-nav .collapse li a {
    color: #cbd5e1;
    padding: 12px 20px 12px 45px;
    display: flex;
    align-items: center;
    transition: var(--transition);
}

.side-nav .collapse li a:hover {
    background-color: #1e293b;
    color: white;
    padding-left: 50px;
}

.caret {
    transition: var(--transition);
}

.dropdown-toggle.collapsed .caret {
    transform: rotate(-90deg);
}

/* Mobile responsiveness */
@media (max-width: 768px) {
    .navbar-brand {
        font-size: 1.2rem;
        padding: 22px 10px;
    }
    
    .top-nav > li > a {
        padding: 25px 10px;
    }
    
    .side-nav {
        width: 100%;
    }
    
    .navbar-collapse {
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
    }
}
</style>

<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="index">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 10px;">
                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                <polyline points="14 2 14 8 20 8"></polyline>
                <line x1="16" y1="13" x2="8" y2="13"></line>
                <line x1="16" y1="17" x2="8" y2="17"></line>
                <polyline points="10 9 9 9 8 9"></polyline>
            </svg>
            Online Notes Sharing
        </a>
    </div>
    
    <ul class="nav navbar-right top-nav">
        <?php if($_SESSION['role'] !== 'admin') { ?> 
        <li>
            <a href="./uploadnote.php" class="upload-btn">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 5px;">
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                    <polyline points="17 8 12 3 7 8"></polyline>
                    <line x1="12" y1="3" x2="12" y2="15"></line>
                </svg>
                UPLOAD
            </a>
        </li> 
        <?php } ?>
        <li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 8px;">
                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                    <circle cx="12" cy="7" r="4"></circle>
                </svg>
                <?php echo $_SESSION['name']; ?>
                <b class="caret"></b>
            </a>
            <ul class="dropdown-menu">
                <li>
                    <a href="./userprofile.php?section=<?php echo $_SESSION['username']; ?>">
                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 8px;">
                            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                            <circle cx="12" cy="7" r="4"></circle>
                        </svg>
                        Account
                    </a>
                </li>
                <li class="divider"></li>
                <li>
                    <a href="../logout.php">
                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 8px;">
                            <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
                            <polyline points="16 17 21 12 16 7"></polyline>
                            <line x1="21" y1="12" x2="9" y2="12"></line>
                        </svg>
                        Log Out
                    </a>
                </li>
            </ul>
        </li>
    </ul>

    <div class="collapse navbar-collapse navbar-ex1-collapse">
        <ul class="nav navbar-nav side-nav">
            <li>
                <a href="index.php" class="active">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 10px;">
                        <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                        <polyline points="9 22 9 12 15 12 15 22"></polyline>
                    </svg>
                    Dashboard
                </a>
            </li>
            <?php if($_SESSION['role'] == 'admin') { ?>
            <li>
                <a href="javascript:;" data-toggle="collapse" data-target="#user">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 10px;">
                        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                        <circle cx="9" cy="7" r="4"></circle>
                        <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                        <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                    </svg>
                    Users
                    <b class="caret pull-right" style="margin-top: 8px;"></b>
                </a>
                <ul id="user" class="collapse">
                    <li>
                        <a href="./users.php">
                            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 10px;">
                                <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                                <circle cx="9" cy="7" r="4"></circle>
                                <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                                <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                            </svg>
                            View All Users
                        </a>
                    </li>
                </ul>
            </li>
            <li>
                <a href="javascript:;" class="dropdown-toggle" data-toggle="collapse" data-target="#posts">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 10px;">
                        <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"></path>
                    </svg>
                    My Account
                    <b class="caret pull-right" style="margin-top: 8px;"></b>
                </a>
                <ul id="posts" class="collapse">
                    <li>
                        <a href="./viewprofile.php?name=<?php echo $_SESSION['username']; ?>">
                            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 10px;">
                                <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                                <circle cx="12" cy="12" r="3"></circle>
                            </svg>
                            View Profile
                        </a>
                    </li>
                    <li>
                        <a href="./userprofile.php?section=<?php echo $_SESSION['username']; ?>">
                            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 10px;">
                                <path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"></path>
                            </svg>
                            Edit Profile
                        </a>
                    </li>
                </ul>
            </li>
            <?php } else { ?>
            <li>
                <a href="javascript:;" data-toggle="collapse" data-target="#user">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 10px;">
                        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                        <polyline points="14 2 14 8 20 8"></polyline>
                        <line x1="16" y1="13" x2="8" y2="13"></line>
                        <line x1="16" y1="17" x2="8" y2="17"></line>
                        <polyline points="10 9 9 9 8 9"></polyline>
                    </svg>
                    My Notes
                    <b class="caret pull-right" style="margin-top: 8px;"></b>
                </a>
                <ul id="user" class="collapse">
                    <li>
                        <a href="./notes.php">
                            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 10px;">
                                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                                <polyline points="14 2 14 8 20 8"></polyline>
                            </svg>
                            View All Notes
                        </a>
                    </li>
                    <li>
                        <a href="./uploadnote.php">
                            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 10px;">
                                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                                <polyline points="17 8 12 3 7 8"></polyline>
                                <line x1="12" y1="3" x2="12" y2="15"></line>
                            </svg>
                            Upload Note
                        </a>
                    </li>
                </ul>
            </li>
            <li>
                <a href="javascript:;" class="dropdown-toggle" data-toggle="collapse" data-target="#posts">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 10px;">
                        <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"></path>
                    </svg>
                    My Account
                    <b class="caret pull-right" style="margin-top: 8px;"></b>
                </a>
                <ul id="posts" class="collapse">
                    <li>
                        <a href="./viewprofile.php?name=<?php echo $_SESSION['username']; ?>">
                            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 10px;">
                                <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                                <circle cx="12" cy="12" r="3"></circle>
                            </svg>
                            View Profile
                        </a>
                    </li>
                    <li>
                        <a href="./userprofile.php?section=<?php echo $_SESSION['username']; ?>">
                            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 10px;">
                                <path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"></path>
                            </svg>
                            Edit Profile
                        </a>
                    </li>
                </ul>
            </li>
            <?php } ?>
        </ul>
    </div>
</nav>