<?php
include ('includes/connection.php');
include ('includes/adminheader.php');
?>

<div id="wrapper">
    <?php include 'includes/adminnav.php';?>
    
    <div id="page-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6 col-lg-offset-3">
                    <?php 
                    if (isset($_GET['name'])) {
                        $user = mysqli_real_escape_string($conn, $_GET['name']);
                        $query = "SELECT * FROM users WHERE username= '$user' ";
                        $run_query = mysqli_query($conn, $query) or die(mysqli_error($conn));
                        
                        if (mysqli_num_rows($run_query) > 0) {
                            while ($row = mysqli_fetch_array($run_query)) {
                                $name = $row['name'];
                                $email = $row['email'];
                                $course = $row['course'];
                                $role = $row['role'];
                                $bio = $row['about'];
                                $image = $row['image'];
                                $joindate = $row['joindate'];
                                $gender = $row['gender'];
                            }
                        } else {
                            $name = "N/A";
                            $email = "N/A";
                            $course = "N/A";
                            $role = "N/A";
                            $bio = "N/A";
                            $image = "profile.jpg";
                            $gender = "N/A";
                            $joindate = "N/A";
                        }
                    ?>

                    <div class="id-card-container">
                        <div class="id-card">
                            <div class="id-card-header">
                                <h2>Online Notes Sharing</h2>
                                <div class="id-card-logo">
                                    <i class="fas fa-id-card"></i>
                                </div>
                            </div>
                            
                            <div class="id-card-body">
                                <div class="id-card-photo">
                                    <img src="profilepics/<?php echo $image; ?>" alt="<?php echo $name; ?>">
                                </div>
                                
                                <div class="id-card-info">
                                    <h3 class="id-card-name"><?php echo $name; ?></h3>
                                    <div class="id-card-details">
                                        <div class="detail-row">
                                            <span class="detail-label">Department:</span>
                                            <span class="detail-value"><?php echo $course; ?></span>
                                        </div>
                                        <div class="detail-row">
                                            <span class="detail-label">Role:</span>
                                            <span class="detail-value"><?php echo $role; ?></span>
                                        </div>
                                        <div class="detail-row">
                                            <span class="detail-label">Gender:</span>
                                            <span class="detail-value"><?php echo $gender; ?></span>
                                        </div>
                                        <div class="detail-row">
                                            <span class="detail-label">Email:</span>
                                            <span class="detail-value"><?php echo $email; ?></span>
                                        </div>
                                        <div class="detail-row">
                                            <span class="detail-label">Join Date:</span>
                                            <span class="detail-value"><?php echo date('F j, Y', strtotime($joindate)); ?></span>
                                        </div>
                                    </div>
                                    
                                    <div class="id-card-bio">
                                        <h4>Bio:</h4>
                                        <p><?php echo $bio ?: 'No bio available'; ?></p>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="id-card-footer">
                                <div class="id-card-id">ID: <?php echo substr(md5($email), 0, 8); ?></div>
                                <span class="signature"><?php echo $name; ?></span>
                            </div>
                        </div>
                    </div>

                    <?php } else {
                        header("location:index.php");
                    } ?>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    /* ID Card Styling with Accurate Colors */
    .id-card-container {
        perspective: 1000px;
        margin: 30px auto;
        max-width: 500px;
    }
    
    .id-card {
        background: #ffffff;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        overflow: hidden;
        border: 1px solid #e0e0e0;
        transform-style: preserve-3d;
        transition: all 0.3s ease;
        position: relative;
    }
    
    .id-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 6px 18px rgba(0, 0, 0, 0.15);
    }
    
    .id-card-header {
        background: #4285f4; /* Google blue */
        color: white;
        padding: 15px 20px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        border-bottom: 1px solid rgba(255, 255, 255, 0.2);
    }
    
    .id-card-header h2 {
        margin: 0;
        font-size: 20px;
        font-weight: 500;
    }
    
    .id-card-logo {
        font-size: 22px;
        background: rgba(255, 255, 255, 0.2);
        width: 40px;
        height: 40px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .id-card-body {
        display: flex;
        padding: 20px;
        background-color: #ffffff;
    }
    
    .id-card-photo {
        width: 120px;
        height: 140px;
        border: 2px solid #f1f1f1;
        border-radius: 4px;
        overflow: hidden;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
        margin-right: 20px;
        background: #f8f9fa;
    }
    
    .id-card-photo img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }
    
    .id-card-info {
        flex: 1;
    }
    
    .id-card-name {
        margin: 0 0 10px 0;
        color: #202124; /* Dark gray */
        font-size: 22px;
        font-weight: 500;
        border-bottom: 1px solid #e0e0e0;
        padding-bottom: 5px;
    }
    
    .id-card-details {
        margin-bottom: 10px;
    }
    
    .detail-row {
        display: flex;
        margin-bottom: 6px;
    }
    
    .detail-label {
        font-weight: 500;
        color: #5f6368; /* Medium gray */
        width: 90px;
        font-size: 14px;
    }
    
    .detail-value {
        color: #202124; /* Dark gray */
        font-size: 14px;
        flex: 1;
    }
    
    .id-card-bio {
        background: #f8f9fa;
        padding: 12px;
        border-radius: 4px;
        margin-top: 12px;
    }
    
    .id-card-bio h4 {
        margin: 0 0 6px 0;
        font-size: 14px;
        color: #5f6368; /* Medium gray */
        font-weight: 500;
    }
    
    .id-card-bio p {
        margin: 0;
        font-size: 14px;
        color: #202124; /* Dark gray */
        line-height: 1.4;
    }
    
    .id-card-footer {
        background: #f8f9fa;
        padding: 10px 20px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        border-top: 1px solid #e0e0e0;
    }
    
    .id-card-id {
        font-size: 12px;
        color: #5f6368; /* Medium gray */
        font-family: 'Roboto', sans-serif;
    }
    
    .signature {
        font-style: italic;
        color: #5f6368; /* Medium gray */
        font-size: 12px;
    }
    
    /* Holographic effect - subtle version */
    .id-card::after {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: linear-gradient(135deg, 
            rgba(66, 133, 244, 0.03) 0%, 
            rgba(255,255,255,0) 50%, 
            rgba(66, 133, 244, 0.03) 100%);
        pointer-events: none;
    }
</style>

<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- Font Awesome for icons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<!-- Google Fonts - Roboto -->
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">

<script>
    $(document).ready(function() {
        // Tilt effect on hover
        $('.id-card').on('mousemove', function(e) {
            const card = $(this);
            const cardWidth = card.width();
            const cardHeight = card.height();
            const centerX = card.offset().left + cardWidth/2;
            const centerY = card.offset().top + cardHeight/2;
            const mouseX = e.pageX - centerX;
            const mouseY = e.pageY - centerY;
            const rotateY = 10 * mouseX / cardWidth;
            const rotateX = -10 * mouseY / cardHeight;
            
            card.css('transform', `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)`);
        });
        
        $('.id-card').on('mouseleave', function() {
            $(this).css('transform', 'perspective(1000px) rotateX(0) rotateY(0)');
        });
    });
</script>

</body>
</html>