<?php include 'includes/connection.php';?>
<?php include 'includes/adminheader.php';?>




<div id="wrapper">

       <?php include 'includes/adminnav.php';?>
        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            UPLOAD NOTE
                        </h1>
                        <div class="table-responsive" style="background: #ffffff; padding: 20px; border-radius: 10px; box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);">
                            <form role="form" action="" method="POST" enctype="multipart/form-data">

                                <div class="form-group">
                                    <label for="post_title" style="color: #495057; font-weight: 500;">Note Title</label>
                                    <input type="text" name="title" class="form-control" style="border-radius: 5px; border: 1px solid #ced4da;" placeholder="Eg: Php Tutorial File">
                                </div>

                                <div class="form-group">
                                    <label for="post_tags" style="color: #495057; font-weight: 500;">Note Tags</label>
                                    <input type="text" name="tags" class="form-control" style="border-radius: 5px; border: 1px solid #ced4da;" placeholder="Eg: Php, Tutorial, Learn Php etc..">
                                </div>

                                <div class="form-group">
                                    <label for="post_content" style="color: #495057; font-weight: 500;">Write a short Description about your note</label>
                                    <textarea class="form-control" name="description" style="border-radius: 5px; border: 1px solid #ced4da;" rows="6"></textarea>
                                </div>

                                <div class="form-group">
                                    <label for="post_image" style="color: #495057; font-weight: 500;">Select File</label>
                                    <input type="file" name="file" class="form-control-file" style="margin-top: 5px;">
                                </div>

                                <button type="submit" name="upload" class="btn btn-primary" value="Upload Note" style="padding: 8px 20px; border-radius: 5px; transition: all 0.3s;">Upload Note</button>
<br>
<br>
</form>
</div>
</div>
</div>
</div>
</div>


<script src="js/jquery.js"></script>

    
    <script src="js/bootstrap.min.js"></script>

</body>

</html>



