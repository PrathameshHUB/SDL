<?php
include ('includes/connection.php');
include ('includes/adminheader.php');

if (isset($_SESSION['username'])) {
    $username = $_SESSION['username'];
    $query = "SELECT * FROM users WHERE username = '$username'";
    $result = mysqli_query($conn, $query) or die(mysqli_error($conn));
    
    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_array($result);
        $userid = $row['id'];
        $usernm = $row['username'];
        $userpassword = $row['password'];
        $useremail = $row['email'];
        $name = $row['name'];
        $profilepic = $row['image'];
        $bio = $row['about'];
    }
    
    // Profile photo upload handling
    if (isset($_POST['uploadphoto'])) {
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $target_dir = "profilepics/";
            $target_file = $target_dir . basename($_FILES["image"]["name"]);
            $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
            
            // Allow only image file types
            $allowedTypes = ['jpg', 'jpeg', 'png', 'gif'];
            if (in_array($imageFileType, $allowedTypes)) {
                if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
                    $filename = basename($_FILES["image"]["name"]);
                    $update_img = "UPDATE users SET image='$filename' WHERE id='$userid'";
                    if (mysqli_query($conn, $update_img)) {
                        $profilepic = $filename;
                        echo "<script>alert('✅ Profile picture updated successfully'); window.location='profile.php';</script>";
                    } else {
                        echo "<script>alert('❌ Failed to update profile picture in database');</script>";
                    }
                } else {
                    echo "<script>alert('❌ Failed to upload image');</script>";
                }
            } else {
                echo "<script>alert('❌ Only JPG, JPEG, PNG & GIF files are allowed.');</script>";
            }
        }
    }
    
    
    if (isset($_POST['update'])) {
        $new_name = mysqli_real_escape_string($conn, $_POST['name']);
        $new_email = mysqli_real_escape_string($conn, $_POST['email']);
        $new_bio = mysqli_real_escape_string($conn, $_POST['bio']);
        $current_pass = mysqli_real_escape_string($conn, $_POST['currentpassword']);
        $new_pass = mysqli_real_escape_string($conn, $_POST['newpassword']);
        $confirm_pass = mysqli_real_escape_string($conn, $_POST['confirmnewpassword']);
        
        // Verify current password
        if (password_verify($current_pass, $userpassword)) {
            if (!empty($new_pass)) {
                if ($new_pass === $confirm_pass) {
                    $hashed_pass = password_hash($new_pass, PASSWORD_BCRYPT);
                    $update_query = "UPDATE users SET name='$new_name', email='$new_email', about='$new_bio', password='$hashed_pass' WHERE id='$userid'";
                } else {
                    echo "<script>alert('❌ New passwords do not match.');</script>";
                    return;
                }
            } else {
                $update_query = "UPDATE users SET name='$new_name', email='$new_email', about='$new_bio' WHERE id='$userid'";
            }
            
            if (mysqli_query($conn, $update_query)) {
                $_SESSION['name'] = $new_name;
                echo "<script>alert('✅ Profile updated successfully.'); window.location='userprofile.php';</script>";
            } else {
                echo "<script>alert('❌ Update failed. Please try again.');</script>";
            }
        } else {
            echo "<script>alert('❌ Current password is incorrect.');</script>";
        }
    }
}
?>


<div id="wrapper">
    <?php include 'includes/adminnav.php';?>
    
    <div id="page-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-8 col-lg-offset-2">
                    <div class="profile-container">
                        <!-- Profile Header -->
                        <div class="profile-header">
                            <h1><i class="fas fa-user-circle"></i> My Profile</h1>
                            <p class="welcome-text">Welcome back, <?php echo $_SESSION['name']; ?></p>
                        </div>
                        
                        <!-- Profile Card -->
                        <div class="profile-card">
                            <div class="row">
                                <!-- Left Column - Profile Picture -->
                                <div class="col-md-4">
                                    <div class="profile-picture-container">
                                        <div class="profile-picture-wrapper">
                                            <img class="profile-picture" src="profilepics/<?php echo $profilepic; ?>" alt="Profile Photo">
                                            <div class="picture-overlay">
                                                <form role="form" action="" method="POST" enctype="multipart/form-data">
                                                    <label for="image-upload" class="upload-btn">
                                                        <i class="fas fa-camera"></i> Change Photo
                                                    </label>
                                                    <input type="file" id="image-upload" name="image" style="display: none;">
                                                    <button type="submit" name="uploadphoto" class="save-btn">Save</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="profile-quick-info">
                                        <h3><?php echo $name; ?></h3>
                                        <p><i class="fas fa-user"></i> <?php echo $username; ?></p>
                                        <p><i class="fas fa-envelope"></i> <?php echo $useremail; ?></p>
                                    </div>
                                </div>
                                
                                <!-- Right Column - Profile Form -->
                                <div class="col-md-8">
                                    <form role="form" action="" method="POST" class="profile-form">
                                        <div class="form-section">
                                            <h3><i class="fas fa-user-edit"></i> Basic Information</h3>
                                            <div class="form-group">
                                                <label for="username">Username</label>
                                                <div class="input-group">
                                                    <span class="input-group-addon"><i class="fas fa-at"></i></span>
                                                    <input type="text" name="username" class="form-control" value="<?php echo $username; ?>" readonly>
                                                </div>
                                            </div>
                                            
                                            <div class="form-group">
                                                <label for="name">Full Name</label>
                                                <div class="input-group">
                                                    <span class="input-group-addon"><i class="fas fa-signature"></i></span>
                                                    <input type="text" name="name" class="form-control" value="<?php echo $name; ?>" required>
                                                </div>
                                            </div>
                                            
                                            <div class="form-group">
                                                <label for="email">Email Address</label>
                                                <div class="input-group">
                                                    <span class="input-group-addon"><i class="fas fa-envelope"></i></span>
                                                    <input type="email" name="email" class="form-control" value="<?php echo $useremail; ?>" required>
                                                </div>
                                            </div>
                                            
                                            <div class="form-group">
                                                <label for="bio">About Me</label>
                                                <textarea class="form-control" name="bio" rows="4" placeholder="Tell us about yourself..."><?php echo $bio; ?></textarea>
                                            </div>
                                        </div>
                                        
                                        <div class="form-section password-section">
                                            <h3><i class="fas fa-lock"></i> Password Settings</h3>
                                            <div class="alert alert-info">
                                                <i class="fas fa-info-circle"></i> Changing password is optional. Leave blank if you don't want to change.
                                            </div>
                                            
                                            <div class="form-group">
                                                <label for="currentpassword">Current Password</label>
                                                <div class="input-group">
                                                    <span class="input-group-addon"><i class="fas fa-key"></i></span>
                                                    <input type="password" name="currentpassword" class="form-control" placeholder="Enter current password" required>
                                                </div>
                                            </div>
                                            
                                            <div class="form-group">
                                                <label for="newpassword">New Password</label>
                                                <div class="input-group">
                                                    <span class="input-group-addon"><i class="fas fa-key"></i></span>
                                                    <input type="password" name="newpassword" class="form-control" placeholder="Enter new password">
                                                </div>
                                            </div>
                                            
                                            <div class="form-group">
                                                <label for="confirmnewpassword">Confirm New Password</label>
                                                <div class="input-group">
                                                    <span class="input-group-addon"><i class="fas fa-key"></i></span>
                                                    <input type="password" name="confirmnewpassword" class="form-control" placeholder="Re-enter new password">
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="form-actions">
                                            <button type="submit" name="update" class="btn btn-update">
                                                <i class="fas fa-save"></i> Update Profile
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    /* Modern Profile Design */
    .profile-container {
        margin-top: 20px;
    }
    
    .profile-header {
        text-align: center;
        margin-bottom: 30px;
        padding: 20px;
        background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
        color: white;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }
    
    .profile-header h1 {
        font-weight: 600;
        margin-bottom: 5px;
    }
    
    .welcome-text {
        font-size: 16px;
        opacity: 0.9;
    }
    
    .profile-card {
        background: white;
        border-radius: 8px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        padding: 30px;
        margin-bottom: 30px;
    }
    
    .profile-picture-container {
        text-align: center;
        margin-bottom: 20px;
    }
    
    .profile-picture-wrapper {
        position: relative;
        display: inline-block;
        width: 200px;
        height: 200px;
        border-radius: 50%;
        overflow: hidden;
        border: 5px solid #f8f9fa;
        box-shadow: 0 3px 10px rgba(0,0,0,0.1);
    }
    
    .profile-picture {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }
    
    .picture-overlay {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0,0,0,0.5);
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        opacity: 0;
        transition: all 0.3s ease;
    }
    
    .profile-picture-wrapper:hover .picture-overlay {
        opacity: 1;
    }
    
    .upload-btn {
        color: white;
        background: transparent;
        border: 2px solid white;
        padding: 8px 15px;
        border-radius: 30px;
        cursor: pointer;
        margin-bottom: 10px;
        transition: all 0.3s ease;
    }
    
    .upload-btn:hover {
        background: rgba(255,255,255,0.2);
    }
    
    .save-btn {
        background: #2575fc;
        color: white;
        border: none;
        padding: 6px 15px;
        border-radius: 4px;
        cursor: pointer;
        transition: all 0.3s ease;
    }
    
    .save-btn:hover {
        background: #1a68e0;
    }
    
    .profile-quick-info {
        text-align: center;
        padding: 15px;
        background: #f8f9fa;
        border-radius: 8px;
    }
    
    .profile-quick-info h3 {
        margin-top: 0;
        color: #343a40;
    }
    
    .profile-quick-info p {
        margin-bottom: 5px;
        color: #6c757d;
    }
    
    .form-section {
        margin-bottom: 25px;
        padding-bottom: 20px;
        border-bottom: 1px solid #eee;
    }
    
    .form-section:last-child {
        border-bottom: none;
    }
    
    .form-section h3 {
        color: #495057;
        margin-bottom: 20px;
        padding-bottom: 10px;
        border-bottom: 2px solid #f1f1f1;
    }
    
    .form-section h3 i {
        margin-right: 10px;
        color: #6a11cb;
    }
    
    .password-section h3 i {
        color: #2575fc;
    }
    
    .input-group-addon {
        background-color: #f8f9fa;
        border-right: none;
    }
    
    .form-control {
        border-left: none;
        transition: all 0.3s;
    }
    
    .form-control:focus {
        box-shadow: none;
        border-color: #ced4da;
    }
    
    .form-actions {
        text-align: right;
        margin-top: 20px;
    }
    
    .btn-update {
        background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
        color: white;
        border: none;
        padding: 10px 25px;
        border-radius: 30px;
        font-weight: 500;
        transition: all 0.3s;
    }
    
    .btn-update:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    }
    
    .alert-info {
        background-color: #e7f5ff;
        border-color: #d0ebff;
        color: #1864ab;
    }
    
    textarea.form-control {
        resize: none;
        min-height: 120px;
    }
</style>

<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- Font Awesome for icons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

<script>
    $(document).ready(function() {
        // Preview image before upload
        $("#image-upload").change(function() {
            if (this.files && this.files[0]) {
                var reader = new FileReader();
                
                reader.onload = function(e) {
                    $('.profile-picture').attr('src', e.target.result);
                }
                
                reader.readAsDataURL(this.files[0]);
            }
        });
        
        // Add smooth transitions
        $('.form-control').focus(function() {
            $(this).parent().parent().css('border-color', '#6a11cb');
        }).blur(function() {
            $(this).parent().parent().css('border-color', '#ced4da');
        });
    });
</script>

</body>
</html>