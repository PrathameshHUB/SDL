<?php include 'includes/connection.php';?>
<?php include 'includes/adminheader.php';?>

<?php 
if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin') {
    header("location: index.php");
}
?>

<div id="wrapper">
    <?php include 'includes/adminnav.php';?>
    <div id="page-wrapper">
        <div class="container-fluid">
            <!-- Page Heading -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="page-header-wrapper">
                        <h1 class="page-header">
                            UPLOAD NOTE
                        </h1>
                        <p class="page-subtitle">Upload study materials for your course</p>
                    </div>

                    <?php
                    if (isset($_POST['upload'])) {
                        require "../gump.class.php";
                        $gump = new GUMP();
                        $_POST = $gump->sanitize($_POST); 

                        $gump->validation_rules(array(
                            'title'    => 'required|max_len,60|min_len,3',
                            'description'   => 'required|max_len,150|min_len,3',
                        ));
                        $gump->filter_rules(array(
                            'title' => 'trim|sanitize_string',
                            'description' => 'trim|sanitize_string',
                        ));
                        $validated_data = $gump->run($_POST);

                        if($validated_data === false) {
                            ?>
                            <div class="alert alert-danger alert-dismissible fade in">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                <?php echo $gump->get_readable_errors(true); ?>
                            </div>
                            <?php 
                            $file_title = $_POST['title'];
                            $file_description = $_POST['description'];
                        }
                        else {
                            $file_title = $validated_data['title'];
                            $file_description = $validated_data['description'];
                            if (isset($_SESSION['id'])) {
                                $file_uploader = $_SESSION['username'];
                                $file_uploaded_to = $_SESSION['course'];
                            }

                            $file = $_FILES['file']['name'];
                            $ext = pathinfo($file, PATHINFO_EXTENSION);
                            $validExt = array ('pdf', 'txt', 'doc', 'docx', 'ppt' , 'zip');
                            if (empty($file)) {
                                echo '<div class="alert alert-warning alert-dismissible fade in">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    Please attach a file
                                </div>';
                            }
                            else if ($_FILES['file']['size'] <= 0 || $_FILES['file']['size'] > 30720000 ) {
                                echo '<div class="alert alert-warning alert-dismissible fade in">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    File size is not proper (max 30MB allowed)
                                </div>';
                            }
                            else if (!in_array($ext, $validExt)) {
                                echo '<div class="alert alert-warning alert-dismissible fade in">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    Not a valid file type (allowed: pdf, txt, doc, docx, ppt, zip)
                                </div>';
                            }
                            else {
                                $folder  = 'allfiles/';
                                $fileext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
                                $notefile = rand(1000 , 1000000) .'.'.$fileext;
                                if(move_uploaded_file($_FILES['file']['tmp_name'], $folder.$notefile)) {
                                    $query = "INSERT INTO uploads(file_name, file_description, file_type, file_uploader, file_uploaded_to, file) VALUES ('$file_title' , '$file_description' , '$fileext' , '$file_uploader' , '$file_uploaded_to' , '$notefile')";
                                    $result = mysqli_query($conn , $query) or die(mysqli_error($conn));
                                    if (mysqli_affected_rows($conn) > 0) {
                                        echo '<div class="alert alert-success alert-dismissible fade in">
                                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                            File uploaded successfully. It will be published after admin approves it.
                                        </div>';
                                        echo "<script>window.location.href='notes.php';</script>";
                                    }
                                    else {
                                        echo '<div class="alert alert-danger alert-dismissible fade in">
                                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                            Error while uploading. Please try again.
                                        </div>';
                                    }
                                }
                            }
                        }
                    }
                    ?>

                    <div class="upload-form-container">
                        <form role="form" action="" method="POST" enctype="multipart/form-data">
                            <div class="form-group">
                                <label for="post_title">Note Title</label>
                                <input type="text" name="title" class="form-control" placeholder="Eg: Php Tutorial File" value="<?php if(isset($_POST['upload'])) { echo htmlspecialchars($file_title); } ?>" required>
                            </div>

                            <div class="form-group">
                                <label for="post_tags">Short Note Description</label>
                                <textarea name="description" class="form-control" rows="3" placeholder="Eg: Php Tutorial File includes basic php programming ...." required><?php if(isset($_POST['upload'])) { echo htmlspecialchars($file_description); } ?></textarea>
                            </div>

                            <div class="form-group file-upload-wrapper">
                                <label for="post_image">Select File</label>
                                <div class="file-upload-box">
                                    <div class="file-upload-info">
                                        <p>Allowed file types: pdf, doc, ppt, txt, zip</p>
                                        <p>Maximum file size: 30 MB</p>
                                    </div>
                                    <div class="custom-file">
                                        <input type="file" name="file" class="custom-file-input" id="customFile">
                                        <label class="custom-file-label" for="customFile">Choose file</label>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group submit-btn-wrapper">
                                <button type="submit" name="upload" class="btn btn-primary btn-upload">
                                    <i class="fa fa-upload"></i> Upload Note
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>

<style>
    .page-header-wrapper {
        margin-bottom: 30px;
        padding-bottom: 15px;
        border-bottom: 1px solid #eee;
    }
    
    .page-subtitle {
        color: #6c757d;
        font-size: 16px;
        margin-top: 10px;
    }
    
    .upload-form-container {
        background: #ffffff;
        padding: 30px;
        border-radius: 8px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        margin-bottom: 30px;
    }
    
    .form-group {
        margin-bottom: 25px;
    }
    
    .form-control {
        border-radius: 4px;
        border: 1px solid #e1e5eb;
        padding: 12px 15px;
        transition: all 0.3s;
    }
    
    .form-control:focus {
        border-color: #4a80f0;
        box-shadow: 0 0 0 0.2rem rgba(74, 128, 240, 0.25);
    }
    
    .file-upload-wrapper {
        margin-top: 30px;
    }
    
    .file-upload-box {
        border: 2px dashed #e1e5eb;
        border-radius: 8px;
        padding: 20px;
        text-align: center;
        background-color: #f8f9fa;
        transition: all 0.3s;
    }
    
    .file-upload-box:hover {
        border-color: #4a80f0;
        background-color: #f0f5ff;
    }
    
    .file-upload-info {
        margin-bottom: 15px;
    }
    
    .file-upload-info p {
        margin-bottom: 5px;
        color: #6c757d;
        font-size: 14px;
    }
    
    .custom-file {
        position: relative;
        display: inline-block;
        width: 100%;
        height: calc(2.25rem + 2px);
        margin-bottom: 0;
    }
    
    .custom-file-input {
        position: relative;
        z-index: 2;
        width: 100%;
        height: calc(2.25rem + 2px);
        margin: 0;
        opacity: 0;
    }
    
    .custom-file-label {
        position: absolute;
        top: 0;
        right: 0;
        left: 0;
        z-index: 1;
        height: calc(2.25rem + 2px);
        padding: 0.375rem 0.75rem;
        line-height: 1.5;
        color: #495057;
        background-color: #fff;
        border: 1px solid #ced4da;
        border-radius: 0.25rem;
    }
    
    .custom-file-label::after {
        position: absolute;
        top: 0;
        right: 0;
        bottom: 0;
        z-index: 3;
        display: block;
        height: calc(calc(2.25rem + 2px) - 1px * 2);
        padding: 0.375rem 0.75rem;
        line-height: 1.5;
        color: #495057;
        content: "Browse";
        background-color: #e9ecef;
        border-left: inherit;
        border-radius: 0 0.25rem 0.25rem 0;
    }
    
    .btn-upload {
        padding: 10px 25px;
        border-radius: 4px;
        font-weight: 500;
        letter-spacing: 0.5px;
        transition: all 0.3s;
    }
    
    .btn-upload i {
        margin-right: 8px;
    }
    
    .alert {
        border-radius: 4px;
        margin-bottom: 20px;
    }
</style>

<script>
    // Update file input label with selected file name
    document.querySelector('.custom-file-input').addEventListener('change', function(e) {
        var fileName = e.target.files[0].name;
        var nextSibling = e.target.nextElementSibling;
        nextSibling.innerText = fileName;
    });
</script>

</body>
</html>