<?php
$host = "localhost";
$user = "root";  // Default XAMPP user
$pass = "";  // Default is empty for XAMPP
$dbname = "online_notes"; // The database name you created

$conn = mysqli_connect($host, $user, $pass, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
