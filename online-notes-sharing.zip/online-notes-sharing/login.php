<?php 
session_start();
include 'includes/connection.php'; // ✅ Ensure database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = mysqli_real_escape_string($conn, $_POST['user']);
    $password = mysqli_real_escape_string($conn, $_POST['pass']);

    $query = "SELECT * FROM users WHERE username = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        
        if (password_verify(trim($password), trim($row['password']))) {
            $_SESSION['id'] = $row['id'];
            $_SESSION['username'] = $row['username'];
            $_SESSION['name'] = $row['name'];
            $_SESSION['email']  = $row['email'];
            $_SESSION['role'] = $row['role'];
            $_SESSION['course'] = $row['course'];
            
            header('location: dashboard/');
            exit();
        } else {
            echo "<script>alert('Invalid username/password'); window.location.href='login.php';</script>";
        }
    } else {
        echo "<script>alert('Invalid username/password'); window.location.href='login.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-bg: linear-gradient(135deg, #ff9966, #ff5e62);
            --secondary-bg: linear-gradient(135deg, #6a11cb, #2575fc);
            --text-color: #fff;
            --input-bg: rgba(255, 255, 255, 0.2);
            --button-color: #ff6b6b;
            --button-hover: #ff4757;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background: var(--primary-bg);
            animation: bgAnimation 6s infinite alternate;
            transition: 0.3s;
        }

        @keyframes bgAnimation {
            0% {
                background: var(--primary-bg);
            }
            100% {
                background: var(--secondary-bg);
            }
        }

        .login-card {
            background: rgba(255, 255, 255, 0.2);
            padding: 30px;
            border-radius: 15px;
            backdrop-filter: blur(12px);
            text-align: center;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
            max-width: 400px;
            width: 100%;
            color: var(--text-color);
            transition: 0.3s ease-in-out;
        }

        h1 {
            margin-bottom: 20px;
            font-weight: 600;
        }

        input {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border-radius: 8px;
            border: none;
            outline: none;
            font-size: 16px;
            background: var(--input-bg);
            color: var(--text-color);
            text-align: center;
        }

        input::placeholder {
            color: rgba(255, 255, 255, 0.6);
        }

        .login-submit {
            width: 100%;
            padding: 12px;
            border-radius: 8px;
            border: none;
            background: var(--button-color);
            color: white;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: 0.3s;
            position: relative;
            overflow: hidden;
        }

        .login-submit::before {
            content: "";
            position: absolute;
            top: 50%;
            left: 50%;
            width: 300%;
            height: 300%;
            background: rgba(255, 255, 255, 0.1);
            transition: 0.6s;
            transform: translate(-50%, -50%) scale(0);
            border-radius: 50%;
        }

        .login-submit:hover::before {
            transform: translate(-50%, -50%) scale(1);
        }

        .login-submit:hover {
            background: var(--button-hover);
        }

        .login-help {
            margin-top: 15px;
        }

        .login-help a {
            color: var(--text-color);
            text-decoration: none;
            font-size: 14px;
            margin: 0 10px;
            transition: 0.3s;
        }

        .login-help a:hover {
            text-decoration: underline;
            color: #ffd166;
        }

        /* Toggle Theme */
        .theme-toggle {
            position: absolute;
            top: 20px;
            right: 20px;
            cursor: pointer;
            background: rgba(255, 255, 255, 0.3);
            padding: 10px;
            border-radius: 50%;
            color: #fff;
            font-size: 18px;
            transition: 0.3s;
        }

        .theme-toggle:hover {
            background: rgba(255, 255, 255, 0.6);
        }

        /* Dark Mode */
        body.dark-mode {
            --primary-bg: #1e1e2e;
            --secondary-bg: #121212;
            --text-color: #e0e0e0;
            --input-bg: rgba(50, 50, 50, 0.5);
            --button-color: #00adb5;
            --button-hover: #008b96;
        }
    </style>
</head>
<body>

<!-- Theme Toggle Button -->
<div class="theme-toggle" onclick="toggleTheme()">🌙</div>

<div class="login-card">
    <h1>Log in</h1>
    <form method="POST">
        <input type="text" name="user" placeholder="Username" required>
        <input type="password" name="pass" placeholder="Password" required>
        <input type="submit" name="login" class="login-submit" value="Login">
    </form>
    <div class="login-help">
        <a href="signup.php">Register</a> • <a href="recoverpassword.php">Forgot Password?</a>
    </div>
</div>

<script>
    // Dark Mode Toggle
    function toggleTheme() {
        document.body.classList.toggle('dark-mode');
        let themeToggle = document.querySelector('.theme-toggle');
        themeToggle.textContent = document.body.classList.contains('dark-mode') ? '☀️' : '🌙';
    }
</script>

</body>
</html>
