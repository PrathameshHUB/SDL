<?php
session_start();
require 'includes/connection.php'; // ✅ Ensure correct database connection

// Include PHPMailer
require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';
require 'PHPMailer/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['email'])) {
    $email = mysqli_real_escape_string($conn, $_POST['email']);

    // Step 1: Check if the email exists in the database
    $query = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $query->bind_param("s", $email);
    $query->execute();
    $result = $query->get_result();
    
    if ($result->num_rows > 0) {
        // Email exists, generate a reset token
        $token = bin2hex(random_bytes(32));

        // Step 2: Store token in database with 1-hour expiration
        $update = $conn->prepare("UPDATE users SET reset_token = ?, token_expiry = DATE_ADD(NOW(), INTERVAL 1 HOUR) WHERE email = ?");
        $update->bind_param("ss", $token, $email);
        $update->execute();

        // Step 3: Send the recovery email
        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'prathameshmane228@gmail.com'; // ✅ Replace with your Gmail
            $mail->Password = 'gsyy vhvs zpca yvfd';   // ✅ Use Google App Password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            // Email setup
            $mail->setFrom('prathameshmane228@gmail.com', 'Admin');
            $mail->addAddress($email); // Send to the user who requested
            $mail->isHTML(true);
            $mail->Subject = 'Password Recovery';
            $mail->Body = "<h3>Password Reset Link:</h3>
                <p><a href='http://localhost/online-notes-sharing/reset_password.php?token=$token'>Click here to reset your password</a></p>";

            // Send email
            if ($mail->send()) {
                echo "<script>alert('Recovery email sent! Check your inbox.'); window.location.href='login.php';</script>";
            } else {
                echo "<script>alert('Error sending email: " . $mail->ErrorInfo . "');</script>";
            }
        } catch (Exception $e) {
            echo "<script>alert('Mailer Error: " . $mail->ErrorInfo . "');</script>";
        }
    } else {
        echo "<script>alert('Email not found in our records!'); window.location.href='recoverpassword.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background: linear-gradient(135deg, #667eea, #764ba2);
        }

        .container {
            background: rgba(255, 255, 255, 0.15);
            padding: 30px;
            border-radius: 15px;
            backdrop-filter: blur(10px);
            text-align: center;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
            max-width: 400px;
            width: 100%;
            color: #fff;
        }

        h2 {
            margin-bottom: 20px;
            font-weight: 600;
        }

        input {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border-radius: 8px;
            border: none;
            outline: none;
            font-size: 16px;
        }

        .btn {
            width: 100%;
            padding: 12px;
            border-radius: 8px;
            border: none;
            background: #ff6b6b;
            color: white;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: 0.3s;
        }

        .btn:hover {
            background: #ff4757;
        }

        .link {
            display: block;
            margin-top: 15px;
            color: #f0f0f0;
            text-decoration: none;
            font-size: 14px;
        }

        .link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Forgot Password</h2>
    <form method="POST">
        <input type="email" name="email" placeholder="Enter your registered email" required>
        <button type="submit" class="btn">Send Reset Link</button>
    </form>
    <a href="login.php" class="link">Back to Login</a>
</div>

</body>
</html>
