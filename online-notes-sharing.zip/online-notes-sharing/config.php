<?php
$host = "localhost"; // Change if using a remote server
$user = "root"; // Default XAMPP MySQL user
$password = ""; // Default is empty for XAMPP
$dbname = "online_notes"; // Change this to your actual database name

// Create connection
$conn = new mysqli($host, $user, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
