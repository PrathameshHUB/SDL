<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notes Management System</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome Icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <style>
        :root {
            --primary: #4361ee;
            --secondary: #3f37c9;
            --accent: #4cc9f0;
            --success: #4dd4ac;
            --danger: #f72585;
            --warning: #f9c74f;
            --info: #90e0ef;
            --dark: #232946;
            --light: #f8f9fa;
            --bg-gradient: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f7f7fc;
            color: #333;
            overflow-x: hidden;
        }
        
        /* Navbar styling */
        .main-navbar {
            background: var(--bg-gradient);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            padding: 15px 0;
        }
        
        .brand-logo {
            font-size: 1.8rem;
            font-weight: 700;
            color: white !important;
            letter-spacing: 0.5px;
        }
        
        .nav-link {
            font-weight: 500;
            color: rgba(255, 255, 255, 0.9) !important;
            padding: 8px 15px !important;
            border-radius: 5px;
            transition: all 0.3s ease;
        }
        
        .nav-link:hover {
            background-color: rgba(255, 255, 255, 0.15);
            transform: translateY(-2px);
        }
        
        .nav-link.active {
            background-color: rgba(255, 255, 255, 0.2);
            color: white !important;
        }
        
        /* Hero Section */
        .hero-section {
            position: relative;
            padding-top: 30px;
            padding-bottom: 50px;
            background: linear-gradient(180deg, #f7f7fc 0%, #fff 100%);
        }
        
        .hero-title {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 20px;
            background: var(--bg-gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .hero-subtitle {
            font-size: 1.2rem;
            color: #666;
            margin-bottom: 30px;
        }
        
        .hero-cta {
            padding: 12px 24px;
            font-weight: 600;
            border-radius: 50px;
            box-shadow: 0 5px 15px rgba(67, 97, 238, 0.3);
            transition: all 0.3s ease;
        }
        
        .hero-cta:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(67, 97, 238, 0.4);
        }
        
        /* Carousel styling */
        .main-carousel {
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.15);
        }
        
        .carousel-item {
            height: 400px;
        }
        
        .carousel-item img {
            object-fit: cover;
            height: 100%;
        }
        
        .carousel-caption {
            background: rgba(0, 0, 0, 0.6);
            border-radius: 10px;
            padding: 20px;
            bottom: 40px;
            max-width: 80%;
            margin: 0 auto;
            left: 10%;
            right: 10%;
            backdrop-filter: blur(5px);
        }
        
        .carousel-caption h2 {
            font-weight: 700;
            margin-bottom: 10px;
        }
        
        /* Stats Cards */
        .stat-card {
            position: relative;
            padding: 25px;
            border-radius: 15px;
            margin-top: -50px;
            background: white;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
            border: none;
            transition: all 0.3s ease;
            overflow: hidden;
            z-index: 10;
        }
        
        .stat-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
        }
        
        .stat-card::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 5px;
            background: var(--bg-gradient);
        }
        
        .stat-value {
            font-size: 2.2rem;
            font-weight: 700;
            margin-bottom: 5px;
            background: var(--bg-gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .stat-title {
            text-transform: uppercase;
            font-size: 0.9rem;
            font-weight: 600;
            color: #666;
            letter-spacing: 1px;
        }
        
        .stat-icon {
            position: absolute;
            bottom: 10px;
            right: 10px;
            font-size: 3.5rem;
            opacity: 0.15;
            color: var(--primary);
        }
        
        /* Feature Cards */
        .section-title {
            position: relative;
            font-size: 1.8rem;
            font-weight: 700;
            margin-bottom: 40px;
            text-align: center;
            color: var(--dark);
        }
        
        .section-title::after {
            content: "";
            position: absolute;
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
            width: 70px;
            height: 4px;
            background: var(--bg-gradient);
            border-radius: 5px;
        }
        
        .feature-section {
            padding: 70px 0;
        }
        
        .feature-card {
            position: relative;
            border-radius: 15px;
            padding: 30px 25px;
            background: white;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
            overflow: hidden;
            border: none;
            height: 100%;
        }
        
        .feature-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
        }
        
        .feature-icon-wrapper {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 70px;
            height: 70px;
            border-radius: 50%;
            margin-bottom: 20px;
            background: linear-gradient(135deg, rgba(67, 97, 238, 0.1) 0%, rgba(76, 201, 240, 0.1) 100%);
        }
        
        .feature-icon {
            font-size: 2rem;
            color: var(--primary);
        }
        
        .feature-title {
            font-size: 1.3rem;
            font-weight: 600;
            margin-bottom: 15px;
            color: var(--dark);
        }
        
        /* Content Cards */
        .content-section {
            padding: 50px 0 70px;
        }
        
        .content-card {
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
            border: none;
            transition: all 0.3s ease;
        }
        
        .content-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
        }
        
        .content-card-header {
            background: var(--bg-gradient);
            color: white;
            padding: 15px 20px;
            font-weight: 600;
            letter-spacing: 0.5px;
        }
        
        .table th {
            font-weight: 600;
            color: var(--dark);
        }
        
        .badge {
            padding: 7px 12px;
            border-radius: 50px;
            font-weight: 500;
        }
        
        .action-btn {
            border-radius: 50px;
            padding: 12px 25px;
            font-weight: 500;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
            letter-spacing: 0.5px;
        }
        
        .action-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
        }
        
        .action-btn i {
            margin-right: 8px;
        }
        
        .category-btn {
            text-align: left;
            padding: 12px 20px;
            border-radius: 10px;
            margin-bottom: 10px;
            font-weight: 500;
            transition: all 0.3s ease;
            border: 1px solid rgba(67, 97, 238, 0.2);
        }
        
        .category-btn:hover {
            background-color: rgba(67, 97, 238, 0.1);
            border-color: var(--primary);
        }
        
        .category-btn i {
            margin-right: 10px;
            color: var(--primary);
        }
        
        /* Footer */
        .main-footer {
            background-color: var(--dark);
            color: white;
            padding: 50px 0 20px;
        }
        
        .footer-heading {
            font-size: 1.4rem;
            font-weight: 600;
            margin-bottom: 20px;
            color: white;
        }
        
        .footer-link {
            color: rgba(255, 255, 255, 0.7);
            margin-bottom: 10px;
            display: block;
            transition: all 0.3s ease;
        }
        
        .footer-link:hover {
            color: white;
            transform: translateX(5px);
        }
        
        .footer-social {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 38px;
            height: 38px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.1);
            color: white;
            margin-right: 10px;
            transition: all 0.3s ease;
        }
        
        .footer-social:hover {
            background: var(--primary);
            transform: translateY(-3px);
        }
        
        .footer-bottom {
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            padding-top: 20px;
            margin-top: 30px;
        }
        
        /* Animations */
        .fade-in-up {
            animation: fadeInUp 0.6s ease-out;
        }
        
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        /* Responsive Adjustments */
        @media (max-width: 992px) {
            .hero-title {
                font-size: 2rem;
            }
            
            .carousel-item {
                height: 350px;
            }
            
            .stat-card {
                margin-bottom: 20px;
            }
        }
        
        @media (max-width: 768px) {
            .carousel-item {
                height: 300px;
            }
            
            .carousel-caption {
                padding: 15px;
                bottom: 20px;
            }
            
            .carousel-caption h2 {
                font-size: 1.4rem;
            }
            
            .hero-section {
                padding-top: 20px;
                padding-bottom: 100px;
            }
            
            .stat-card {
                margin-top: -30px;
            }
        }

        /* Dark Mode Styles */
body.dark-mode {
    background-color: #121212;
    color: #e0e0e0;
}

.dark-mode .hero-section {
    background: linear-gradient(180deg, #1e1e1e 0%, #121212 100%);
}

.dark-mode .feature-section.bg-light,
.dark-mode .bg-light {
    background-color: #1e1e1e !important;
}

.dark-mode .card {
    background-color: #1e1e1e;
    border-color: #333;
}

.dark-mode .stat-card,
.dark-mode .feature-card,
.dark-mode .content-card {
    background-color: #2d2d2d;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
}

.dark-mode .table {
    color: #e0e0e0;
}

.dark-mode .table th,
.dark-mode .table thead th {
    background-color: #333;
    color: #fff;
}

.dark-mode .table-hover tbody tr:hover {
    background-color: rgba(255, 255, 255, 0.05);
    color: #fff;
}

.dark-mode .table-light,
.dark-mode .table-light > th,
.dark-mode .table-light > td {
    background-color: #333;
}

.dark-mode .section-title {
    color: #fff;
}

.dark-mode .hero-subtitle {
    color: #aaa;
}

.dark-mode .feature-title {
    color: #fff;
}

.dark-mode .category-btn {
    background-color: #2d2d2d;
    border-color: #444;
    color: #e0e0e0;
}

.dark-mode .category-btn:hover {
    background-color: #3d3d3d;
}

.dark-mode .p-3.rounded-3.bg-light {
    background-color: #2d2d2d !important;
    color: #e0e0e0;
}

.dark-mode .text-muted {
    color: #aaa !important;
}
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark main-navbar">
        <div class="container">
            <a class="navbar-brand brand-logo" href="#">
                <i class="fas fa-graduation-cap me-2"></i> EDU<span style="color: var(--accent);">NOTES</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="index.php"><i class="fas fa-home me-1"></i> Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard/notes.php"><i class="fas fa-book me-1"></i> Notes</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard/"><i class="fas fa-upload me-1"></i> Upload</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="login.php"><i class="fas fa-user me-1"></i> Login</a>
                    </li>
                    <li class="nav-item ms-lg-2 mt-2 mt-lg-0">
                        <a class="btn btn-light rounded-pill px-3 fw-bold" href="signup.php"><i class="fas fa-user-plus me-1"></i> Register</a>
                    </li>
                    <li class="nav-item ms-lg-2 mt-2 mt-lg-0">
                     <button id="darkModeToggle" class="btn btn-outline-light rounded-pill px-3">
                     <i class="fas fa-moon me-1"></i> Dark Mode
                      </button>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-5 mb-5 mb-lg-0">
                    <h1 class="hero-title fade-in-up">Your Academic Success Starts Here</h1>
                    <p class="hero-subtitle fade-in-up">The ultimate platform for teachers and students to share, manage, and access educational resources.</p>
                    <div class="d-flex gap-3 fade-in-up">
                        <a href="#" class="btn btn-primary hero-cta"><i class="fas fa-search me-2"></i> Browse Notes</a>
                        <a href="#" class="btn btn-outline-primary hero-cta"><i class="fas fa-upload me-2"></i> Upload</a>
                    </div>
                </div>
                <div class="col-lg-7">
                    <!-- Main Carousel -->
                    <div id="mainCarousel" class="carousel slide main-carousel fade-in-up" data-bs-ride="carousel">
                        <div class="carousel-indicators">
                            <button type="button" data-bs-target="#mainCarousel" data-bs-slide-to="0" class="active"></button>
                            <button type="button" data-bs-target="#mainCarousel" data-bs-slide-to="1"></button>
                            <button type="button" data-bs-target="#mainCarousel" data-bs-slide-to="2"></button>
                            <button type="button" data-bs-target="#mainCarousel" data-bs-slide-to="3"></button>
                        </div>
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <img src="images/slider/slide1.jpg" class="d-block w-100" alt="Easy Notes Management">
                                <div class="carousel-caption">
                                    <h2><i class="fas fa-sticky-note me-2"></i> Easy Notes Management</h2>
                                    <p>Now easily manage all kind of notes by uploading them here.</p>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <img src="images/slider/slide2.jpg" class="d-block w-100" alt="Upload Various Files">
                                <div class="carousel-caption">
                                    <h2><i class="fas fa-file-upload me-2"></i> Upload Various Files</h2>
                                    <p>User can upload various types of files like PDF, PPT, DOC etc.</p>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <img src="images/slider/slide3.jpg" class="d-block w-100" alt="Controlled By Admin">
                                <div class="carousel-caption">
                                    <h2><i class="fas fa-user-shield me-2"></i> Controlled By Admin</h2>
                                    <p>Everything is managed and controlled by administrator</p>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <img src="images/slider/slide4.jpg" class="d-block w-100" alt="Login For Both Teacher and Student">
                                <div class="carousel-caption">
                                    <h2><i class="fas fa-users me-2"></i> Dual Login System</h2>
                                    <p>Both teacher and student can login and upload notes</p>
                                </div>
                            </div>
                        </div>
                        <button class="carousel-control-prev" type="button" data-bs-target="#mainCarousel" data-bs-slide="prev">
                            <span class="carousel-control-prev-icon"></span>
                        </button>
                        <button class="carousel-control-next" type="button" data-bs-target="#mainCarousel" data-bs-slide="next">
                            <span class="carousel-control-next-icon"></span>
                        </button>
                    </div>
                </div>
            </div>
            
            <!-- Stats Cards -->
            <div class="row mt-4">
                <div class="col-md-3 col-sm-6 mb-4">
                    <div class="card stat-card">
                        <div class="stat-value">1,259</div>
                        <div class="stat-title">Total Notes</div>
                        <div class="stat-icon">
                            <i class="fas fa-book"></i>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 mb-4">
                    <div class="card stat-card">
                        <div class="stat-value">432</div>
                        <div class="stat-title">Active Users</div>
                        <div class="stat-icon">
                            <i class="fas fa-users"></i>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 mb-4">
                    <div class="card stat-card">
                        <div class="stat-value">5,742</div>
                        <div class="stat-title">Downloads</div>
                        <div class="stat-icon">
                            <i class="fas fa-download"></i>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 mb-4">
                    <div class="card stat-card">
                        <div class="stat-value">8</div>
                        <div class="stat-title">File Types</div>
                        <div class="stat-icon">
                            <i class="fas fa-file-alt"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Features Section -->
    <section class="feature-section bg-light">
        <div class="container">
            <h2 class="section-title">Why Choose Our Platform</h2>
            <div class="row">
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="card feature-card">
                        <div class="feature-icon-wrapper">
                            <i class="fas fa-laptop-code feature-icon"></i>
                        </div>
                        <h4 class="feature-title">Easy Notes Management</h4>
                        <p>Our intuitive interface allows you to organize, categorize, and access your educational materials effortlessly.</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="card feature-card">
                        <div class="feature-icon-wrapper">
                            <i class="fas fa-file-upload feature-icon"></i>
                        </div>
                        <h4 class="feature-title">Multiple File Formats</h4>
                        <p>Upload various types of files including PDF, PPT, DOC, and more to share your knowledge effectively.</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="card feature-card">
                        <div class="feature-icon-wrapper">
                            <i class="fas fa-user-shield feature-icon"></i>
                        </div>
                        <h4 class="feature-title">Secure Administration</h4>
                        <p>Advanced administrative controls ensure all content remains appropriate and high-quality.</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="card feature-card">
                        <div class="feature-icon-wrapper">
                            <i class="fas fa-users-cog feature-icon"></i>
                        </div>
                        <h4 class="feature-title">Dual Login System</h4>
                        <p>Specialized portals for both teachers and students with tailored features for each role.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Content Section -->
    <section class="content-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 mb-4">
                    <div class="card content-card">
                        <div class="card-header content-card-header d-flex justify-content-between align-items-center">
                            <h5 class="mb-0"><i class="fas fa-history me-2"></i> Recently Added Notes</h5>
                            <a href="#" class="btn btn-sm btn-light rounded-pill">View All</a>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th scope="col">Title</th>
                                            <th scope="col">Category</th>
                                            <th scope="col">Uploader</th>
                                            <th scope="col">Date</th>
                                            <th scope="col">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td class="fw-medium">Introduction to Programming</td>
                                            <td><span class="badge bg-primary">Computer Science</span></td>
                                            <td>Prof. Smith</td>
                                            <td>Apr 1, 2025</td>
                                            <td><a href="#" class="btn btn-sm btn-outline-primary rounded-pill"><i class="fas fa-download"></i></a></td>
                                        </tr>
                                        <tr>
                                            <td class="fw-medium">Database Systems Notes</td>
                                            <td><span class="badge bg-success">Database</span></td>
                                            <td>Dr. Johnson</td>
                                            <td>Mar 28, 2025</td>
                                            <td><a href="#" class="btn btn-sm btn-outline-primary rounded-pill"><i class="fas fa-download"></i></a></td>
                                        </tr>
                                        <tr>
                                            <td class="fw-medium">Web Development Basics</td>
                                            <td><span class="badge bg-info">Web Design</span></td>
                                            <td>Prof. Williams</td>
                                            <td>Mar 25, 2025</td>
                                            <td><a href="#" class="btn btn-sm btn-outline-primary rounded-pill"><i class="fas fa-download"></i></a></td>
                                        </tr>
                                        <tr>
                                            <td class="fw-medium">Artificial Intelligence</td>
                                            <td><span class="badge bg-primary">AI/ML</span></td>
                                            <td>Dr. Miller</td>
                                            <td>Mar 20, 2025</td>
                                            <td><a href="#" class="btn btn-sm btn-outline-primary rounded-pill"><i class="fas fa-download"></i></a></td>
                                        </tr>
                                        <tr>
                                            <td class="fw-medium">Calculus Advanced Techniques</td>
                                            <td><span class="badge bg-warning">Mathematics</span></td>
                                            <td>Prof. Davis</td>
                                            <td>Mar 18, 2025</td>
                                            <td><a href="#" class="btn btn-sm btn-outline-primary rounded-pill"><i class="fas fa-download"></i></a></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Top Contributors Card -->
                    <div class="card content-card mt-4">
                        <div class="card-header content-card-header">
                            <h5 class="mb-0"><i class="fas fa-award me-2"></i> Top Contributors</h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-4 col-sm-6 mb-4 text-center">
                                    <div class="p-3 rounded-3 bg-light">
                                        <div class="avatar mb-3">
                                            <i class="fas fa-user-circle fa-4x text-primary"></i>
                                        </div>
                                        <h5 class="mb-1">Prof. Smith</h5>
                                        <p class="text-muted small mb-2">Computer Science</p>
                                        <div class="badge bg-primary mb-2">125 Notes</div>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-6 mb-4 text-center">
                                    <div class="p-3 rounded-3 bg-light">
                                        <div class="avatar mb-3">
                                            <i class="fas fa-user-circle fa-4x text-success"></i>
                                        </div>
                                        <h5 class="mb-1">Dr. Johnson</h5>
                                        <p class="text-muted small mb-2">Database Systems</p>
                                        <div class="badge bg-success mb-2">98 Notes</div>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-6 mb-4 text-center">
                                    <div class="p-3 rounded-3 bg-light">
                                        <div class="avatar mb-3">
                                            <i class="fas fa-user-circle fa-4x text-info"></i>
                                        </div>
                                        <h5 class="mb-1">Prof. Davis</h5>
                                        <p class="text-muted small mb-2">Mathematics</p>
                                        <div class="badge bg-info mb-2">87 Notes</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-4">
                    <!-- Quick Actions -->
                    <div class="card content-card mb-4">
                        <div class="card-header content-card-header">
                            <h5 class="mb-0"><i class="fas fa-bolt me-2"></i> Quick Actions</h5>
                        </div>
                        <div class="card-body">
                            <div class="d-grid gap-3">
                                <a href="#" class="btn btn-primary action-btn">
                                    <i class="fas fa-upload"></i> Upload New Note
                                </a>
                                <a href="#" class="btn btn-success action-btn">
                                    <i class="fas fa-search"></i> Browse Notes
                                </a>
                                <a href="#" class="btn btn-info action-btn text-white">
                                    <i class="fas fa-user-plus"></i> Create Account
                                </a>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Popular Categories -->
                    <div class="card content-card mb-4">
                        <div class="card-header content-card-header">
                            <h5 class="mb-0"><i class="fas fa-th-list me-2"></i> Popular Categories</h5>
                        </div>
                        <div class="card-body">
                            <div class="d-grid">
                            <script>
    // Dark Mode Toggle Functionality
    const darkModeToggle = document.getElementById('darkModeToggle');
    const body = document.body;
    
    // Check for saved user preference or system preference
    const prefersDarkScheme = window.matchMedia('(prefers-color-scheme: dark)');
    const currentTheme = localStorage.getItem('theme');
    
    if (currentTheme === 'dark' || (!currentTheme && prefersDarkScheme.matches)) {
        body.classList.add('dark-mode');
        darkModeToggle.innerHTML = '<i class="fas fa-sun me-1"></i> Light Mode';
    }
    
    darkModeToggle.addEventListener('click', () => {
        if (body.classList.contains('dark-mode')) {
            body.classList.remove('dark-mode');
            localStorage.setItem('theme', 'light');
            darkModeToggle.innerHTML = '<i class="fas fa-moon me-1"></i> Dark Mode';
        } else {
            body.classList.add('dark-mode');
            localStorage.setItem('theme', 'dark');
            darkModeToggle.innerHTML = '<i class="fas fa-sun me-1"></i> Light Mode';
        }
    });
</script>
</Body>                                