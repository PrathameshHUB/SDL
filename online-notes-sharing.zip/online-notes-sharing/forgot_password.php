<form action="send_recovery_email.php" method="POST">
    <input type="email" name="email" placeholder="Enter your email" required>
    <button type="submit">Send Recovery Email</button>
</form>
