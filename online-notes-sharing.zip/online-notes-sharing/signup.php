<?php 
session_start();
include 'includes/connection.php';

if (isset($_POST['signup'])) {
    require "gump.class.php";
    $gump = new GUMP();
    $_POST = $gump->sanitize($_POST); 

    $gump->validation_rules(array(
        'username'    => 'required|alpha_numeric|max_len,20|min_len,4',
        'name'        => 'required|alpha_space|max_len,30|min_len,5',
        'email'       => 'required|valid_email',
        'password'    => 'required|max_len,50|min_len,6',
    ));

    $gump->filter_rules(array(
        'username' => 'trim|sanitize_string',
        'name'     => 'trim|sanitize_string',
        'password' => 'trim',
        'email'    => 'trim|sanitize_email',
    ));

    $validated_data = $gump->run($_POST);

    if ($validated_data === false) {
        echo "<script>alert('" . $gump->get_readable_errors(true) . "');</script>";
    } else if ($_POST['password'] !== $_POST['repassword']) {
        echo "<script>alert('Passwords do not match');</script>";
    } else {
        $username = $validated_data['username'];
        $email = $validated_data['email'];
        $checkuser = "SELECT * FROM users WHERE username = '$username' OR email = '$email'";
        $run_check = mysqli_query($conn, $checkuser);

        if (mysqli_num_rows($run_check) > 0) {
            echo "<script>alert('Username or Email already taken! Try another one.');</script>";
        } else {
            $name = $validated_data['name'];
            $pass = password_hash($validated_data['password'], PASSWORD_DEFAULT);
            $role = $_POST['role'];
            $course = $_POST['course'];
            $gender = $_POST['gender'];
            $joindate = date("F j, Y");

            $query = "INSERT INTO users (username, name, email, password, role, course, gender, joindate, token) 
                      VALUES ('$username', '$name', '$email', '$pass', '$role', '$course', '$gender', '$joindate', '')";
            $result = mysqli_query($conn, $query);

            if ($result) {
                echo "<script>alert('Successfully Registered! Redirecting to login...');
                      window.location.href='login.php';</script>";
            } else {
                echo "<script>alert('Error occurred. Please try again.');</script>";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        :root {
    --primary-bg: linear-gradient(135deg, #ff9966, #ff5e62);
    --secondary-bg: linear-gradient(135deg, #6a11cb, #2575fc);
    --text-color: #fff;
    --input-bg: rgba(255, 255, 255, 0.15);
    --button-color: #ff6b6b;
    --button-hover: #ff4757;
    /* --focus-color: #ffdf40; Added for focus effects */
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Poppins', sans-serif;
}

body {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    background: var(--primary-bg);
    animation: bgAnimation 6s infinite alternate;
    transition: 0.3s;
}

@keyframes bgAnimation {
    0% { background: var(--primary-bg); }
    100% { background: var(--secondary-bg); }
}

.signup-card {
    background: rgba(255, 255, 255, 0.2);
    padding: 30px;
    border-radius: 15px;
    backdrop-filter: blur(10px);
    text-align: center;
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.25);
    max-width: 400px;
    width: 100%;
    color: var(--text-color);
    transition: 0.3s;
}

h1 {
    margin-bottom: 20px;
    font-size: 24px;
    font-weight: 600;
}

input, select {
    width: 100%;
    padding: 12px;
    margin: 10px 0;
    border-radius: 8px;
    border: none;
    outline: none;
    font-size: 16px;
    background: var(--input-bg);
    color: var(--text-color);
    text-align: center;
    transition: background-color 0.3s, border 0.3s;
}

input::placeholder {
    color: rgba(255, 255, 255, 0.6);
}

input:focus, select:focus {
    background: var(--focus-color);
    border: 1px solid var(--text-color);
    
}

.signup-submit {
    width: 100%;
    padding: 12px;
    border-radius: 8px;
    border: none;
    background: var(--button-color);
    color: white;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    transition: 0.3s;
    position: relative;
    overflow: hidden;
}

.signup-submit::before {
    content: "";
    position: absolute;
    top: 50%;
    left: 50%;
    width: 300%;
    height: 300%;
    background: rgba(255, 255, 255, 0.1);
    transition: 0.6s;
    transform: translate(-50%, -50%) scale(0);
    border-radius: 50%;
}

.signup-submit:hover::before {
    transform: translate(-50%, -50%) scale(1);
}

.signup-submit:hover {
    background: var(--button-hover);
}

.theme-toggle {
    position: absolute;
    top: 20px;
    right: 20px;
    cursor: pointer;
    background: rgba(255, 255, 255, 0.3);
    padding: 10px;
    border-radius: 50%;
    color: #fff;
    font-size: 18px;
    transition: 0.3s;
}

.theme-toggle:hover {
    background: rgba(255, 255, 255, 0.6);
}

body.dark-mode {
    --primary-bg: #1e1e2e;
    --secondary-bg: #121212;
    --text-color: #e0e0e0;
    --input-bg: rgba(50, 50, 50, 0.5);
    --button-color: #00adb5;
    --button-hover: #008b96;
}

.login-link {
    margin-top: 15px;
    color: var(--text-color);
    font-size: 14px;
}

.login-link a {
    color: white;
    font-weight: 600;
    text-decoration: none;
}

.login-link a:hover {
    text-decoration: underline;
}

/* Media Queries for Responsiveness */
@media (max-width: 480px) {
    .signup-card {
        padding: 20px;
    }

    h1 {
        font-size: 20px;
    }

    input, select {
        font-size: 14px;
    }

    .signup-submit {
        font-size: 14px;
    }
}
    </style>
</head>
<body>

<!-- Theme Toggle Button -->
<div class="theme-toggle" onclick="toggleTheme()">🌙</div>

<div class="signup-card">
    <h1>Sign Up</h1>
    <form method="POST">
        <input type="text" name="name" placeholder="Full Name" required>
        <input type="email" name="email" placeholder="Email" required>
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Password" required>
        <input type="password" name="repassword" placeholder="Confirm Password" required>
        <select name="gender">
            <option value="Male">Male</option>
            <option value="Female">Female</option>
        </select>
        <select name="role">
            <option value="teacher">Teacher</option>
            <option value="student">Student</option>
        </select>
        <select name="course">
            <option value="Computer Science">Computer Science</option>
            <option value="Electrical">Electrical Engineering</option>
            <option value="Mechanical">Mechanical Engineering</option>
        </select>
        <input class="signup-submit" name="signup" value="Sign Up" type="submit">
        
        <div class="login-link">
            Already have an account? <a href="login.php">Log in</a>
        </div>
    </form>
</div>

<script>
    function toggleTheme() {
        document.body.classList.toggle('dark-mode');
    }
</script>

</body>
</html>