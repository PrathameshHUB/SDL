<?php
require 'config.php';

if (isset($_GET['token'])) {
    $token = $_GET['token'];

    // Verify token
    $query = $conn->prepare("SELECT * FROM users WHERE reset_token = ? AND token_expiry > NOW()");
    $query->bind_param("s", $token);
    $query->execute();
    $result = $query->get_result();

    if ($result->num_rows > 0) {
        if (isset($_POST['password'])) {
            $newPassword = password_hash($_POST['password'], PASSWORD_BCRYPT);

            // Update password and remove token
            $update = $conn->prepare("UPDATE users SET password = ?, reset_token = NULL WHERE reset_token = ?");
            $update->bind_param("ss", $newPassword, $token);
            $update->execute();

            echo "<center><font color='green'>Password updated successfully!</font></center>";
        }
    } else {
        echo "<center><font color='red'>Invalid or expired token.</font></center>";
    }
} else {
    echo "<center><font color='red'>No token provided.</font></center>";
}
?>

<form method="POST">
    <input type="password" name="password" placeholder="Enter new password" required>
    <button type="submit">Reset Password</button>
</form>
